* startup benchmark
V1 in 0 1
R1 in 0 1k
.op
.end
